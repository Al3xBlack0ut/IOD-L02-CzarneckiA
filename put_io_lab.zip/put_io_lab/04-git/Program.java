public class Alpaka {
    private String imie;
    private int iloscWelny;
    private boolean czyPluje;

    public Lama(String imie, int iloscWelny, boolean czyPluje) {
        this.imie = imie;
        this.iloscWelny = iloscWelny;
        this.czyPluje = czyPluje;
    }

    public void przedstawSie() {
        System.out.println("Cześć! Jestem " + imie + ".");
        System.out.println("Mam " + iloscWelny + " gramów wełny.");
        System.out.println(czyPluje ? "Uwaga, potrafię pluć!" : "Spokojnie, nie pluję.");
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public int getIloscWelny() {
        return iloscWelny;
    }

    public void setIloscWelny(int iloscWelny) {
        this.iloscWelny = iloscWelny;
    }

    public boolean isCzyPluje() {
        return czyPluje;
    }

    public void setCzyPluje(boolean czyPluje) {
        this.czyPluje = czyPluje;
    }
}

